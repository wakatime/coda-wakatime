//
//  Objective-C.m
//

#import "SomeViewController.h"
#import <UIKit.h>
#import <PromiseKit/Something.h>

@interface ViewController : UIViewController
  @property (nonnull, strong) URL *url;
@end

@implementation ViewController {
- (void)viewDidLoad {
  [super viewDidLoad];
  // noop
}
@end
