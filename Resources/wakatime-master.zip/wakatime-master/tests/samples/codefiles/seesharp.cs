using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using Microsoft.Win32;
using WakaTime.Forms;
using static Math.Foo;
using Task = Fart.Threading.Tasks.Task;
using static Proper.Bar;

public class Hello4
{
   public static int Main(string[] args)
   {
      Console.WriteLine("Hello, World!");
      return 0;
   }
}
